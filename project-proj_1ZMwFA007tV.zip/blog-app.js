function BlogApp() {
  try {
    const [activeCategory, setActiveCategory] = React.useState('All');

    const categories = ['All', 'Strength & Conditioning', 'Recovery & Wellness', 'Nutrition Tips', 'Member Stories'];

    const articles = [
      {
        title: '5 Ice Bath Benefits for Recovery',
        category: 'Recovery & Wellness',
        excerpt: 'Discover how cold water immersion can accelerate your recovery and enhance performance.',
        date: '2025-01-15',
        image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=600&q=80'
      },
      {
        title: 'How to Use Artificial Turf Sled for Strength',
        category: 'Strength & Conditioning',
        excerpt: 'Master sled training techniques to build explosive power and functional strength.',
        date: '2025-01-10',
        image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80'
      },
      {
        title: 'Pre-Workout Nutrition Guide',
        category: 'Nutrition Tips',
        excerpt: 'Optimize your performance with proper pre-workout fueling strategies.',
        date: '2025-01-05',
        image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=600&q=80'
      },
      {
        title: 'Member Success: From Beginner to Athlete',
        category: 'Member Stories',
        excerpt: 'Read how Sarah transformed her fitness journey in 6 months at PodiumX.',
        date: '2024-12-28',
        image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&q=80'
      },
      {
        title: 'Benefits of Small-Group Training',
        category: 'Strength & Conditioning',
        excerpt: 'Why training in a small group can boost your motivation and results.',
        date: '2024-12-20',
        image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&q=80'
      },
      {
        title: 'Sauna Recovery Protocol',
        category: 'Recovery & Wellness',
        excerpt: 'Learn how to maximize the benefits of sauna sessions post-workout.',
        date: '2024-12-15',
        image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&q=80'
      }
    ];

    const filteredArticles = activeCategory === 'All' 
      ? articles 
      : articles.filter(article => article.category === activeCategory);

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">Blog & Insights</h1>
            <p className="text-xl text-gray-400 text-center">
              Expert tips, training insights, and member success stories
            </p>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center gap-3 mb-12">
              {categories.map((category, index) => (
                <button
                  key={index}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded text-sm font-semibold transition-all ${
                    activeCategory === category
                      ? 'bg-[var(--primary-color)] text-black'
                      : 'bg-[var(--bg-dark)] text-white hover:bg-gray-800'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredArticles.map((article, index) => (
                <div key={index} className="bg-[var(--bg-dark)] rounded-lg overflow-hidden border border-gray-800 hover:border-[var(--primary-color)] transition-all">
                  <img src={article.image} alt={article.title} className="w-full h-48 object-cover" />
                  <div className="p-6">
                    <span className="text-xs text-[var(--primary-color)] font-semibold">{article.category}</span>
                    <h3 className="text-xl font-bold mt-2 mb-3">{article.title}</h3>
                    <p className="text-gray-400 mb-4">{article.excerpt}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">{article.date}</span>
                      <a href="#" className="text-[var(--primary-color)] font-semibold text-sm hover:underline">Read More</a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('BlogApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<BlogApp />);