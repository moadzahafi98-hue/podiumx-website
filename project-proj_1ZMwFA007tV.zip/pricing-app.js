function PricingApp() {
  try {
    const pricingPlans = [
      {
        name: 'Small-Group Training',
        price: '549',
        sessions: '3 sessions/week',
        included: ['Group WODs', 'Community training', 'Progress tracking', 'Training zone access'],
        excluded: ['Individual coaching', 'Recovery zone']
      },
      {
        name: 'Individual 2x/week',
        price: '799',
        sessions: '2 sessions/week',
        included: ['Personal coaching', 'Custom programming', 'Monthly reviews', 'All zones access'],
        excluded: []
      },
      {
        name: 'Individual 4x/week',
        price: '1199',
        sessions: '4 sessions/week',
        included: ['Personal coaching', 'Custom programming', 'Monthly reviews', 'All zones access', 'Priority booking'],
        excluded: []
      },
      {
        name: 'Recovery Add-on',
        price: '249',
        sessions: 'Unlimited',
        included: ['Ice baths', 'Sauna access', 'Recovery zone'],
        excluded: ['Training sessions', 'Coaching']
      }
    ];

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">Pricing & Plans</h1>
            <p className="text-xl text-gray-400 text-center max-w-3xl mx-auto">
              All memberships include free initial evaluation (valued at 0 MAD)
            </p>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {pricingPlans.map((plan, index) => (
                <div key={index} className="bg-[var(--bg-dark)] rounded-lg p-6 border border-gray-800">
                  <h3 className="text-xl font-bold mb-4">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-[var(--primary-color)]">{plan.price}</span>
                    <span className="text-gray-400"> MAD/month</span>
                    <p className="text-sm text-gray-500 mt-2">{plan.sessions}</p>
                  </div>
                  <div className="mb-6">
                    <p className="text-sm font-bold mb-2 text-gray-300">Included:</p>
                    <ul className="space-y-2">
                      {plan.included.map((item, idx) => (
                        <li key={idx} className="flex items-start text-sm">
                          <div className="icon-check text-base text-[var(--primary-color)] mr-2"></div>
                          <span className="text-gray-400">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  {plan.excluded.length > 0 && (
                    <div className="mb-6">
                      <p className="text-sm font-bold mb-2 text-gray-300">Not included:</p>
                      <ul className="space-y-2">
                        {plan.excluded.map((item, idx) => (
                          <li key={idx} className="flex items-start text-sm">
                            <div className="icon-x text-base text-gray-600 mr-2"></div>
                            <span className="text-gray-500">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <a href="schedule.html" className="btn-primary w-full text-center block text-sm">Select Plan</a>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-12 text-center">Special Offers</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="bg-[var(--secondary-color)] p-6 rounded-lg border border-[var(--primary-color)]">
                <div className="w-12 h-12 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <div className="icon-calendar text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h3 className="text-xl font-bold mb-2">12-Month Contract</h3>
                <p className="text-3xl font-bold text-[var(--primary-color)] mb-3">10% OFF</p>
                <p className="text-gray-400">Commit for a year and save on any program</p>
              </div>
              <div className="bg-[var(--secondary-color)] p-6 rounded-lg border border-[var(--primary-color)]">
                <div className="w-12 h-12 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <div className="icon-gift text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h3 className="text-xl font-bold mb-2">Referral Bonus</h3>
                <p className="text-3xl font-bold text-[var(--primary-color)] mb-3">1 Month Free</p>
                <p className="text-gray-400">Refer a friend and both get rewards</p>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('PricingApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PricingApp />);