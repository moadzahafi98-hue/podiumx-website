function Newsletter() {
  try {
    const [email, setEmail] = React.useState('');
    const [status, setStatus] = React.useState('');

    const handleSubmit = async (e) => {
      e.preventDefault();
      if (!email) return;
      
      setStatus('Subscribing...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      setStatus('Thank you for subscribing!');
      setEmail('');
      setTimeout(() => setStatus(''), 3000);
    };

    return (
      <section className="py-20 bg-[var(--bg-dark)]" data-name="newsletter" data-file="components/Newsletter.js">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Get Performance Tips & Club Updates</h2>
            <p className="text-gray-400 mb-8">Join our community and receive exclusive training insights, nutrition tips, and special offers.</p>
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="flex-1 px-6 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                required
              />
              <button type="submit" className="btn-primary">Subscribe</button>
            </form>
            {status && <p className="mt-4 text-[var(--primary-color)]">{status}</p>}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Newsletter component error:', error);
    return null;
  }
}