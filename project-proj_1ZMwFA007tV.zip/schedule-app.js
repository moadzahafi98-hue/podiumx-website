function ScheduleApp() {
  try {
    const [formData, setFormData] = React.useState({
      name: '',
      email: '',
      phone: '',
      program: '',
      date: '',
      time: ''
    });
    const [submitted, setSubmitted] = React.useState(false);

    const schedule = [
      { day: 'Monday', slots: ['06:00-10:00 Elite Morning', '12:00-14:00 Express Lunch', '17:00-21:00 Prime Time'] },
      { day: 'Tuesday', slots: ['06:00-10:00 Elite Morning', '12:00-14:00 Express Lunch', '17:00-21:00 Prime Time'] },
      { day: 'Wednesday', slots: ['06:00-10:00 Elite Morning', '12:00-14:00 Express Lunch', '17:00-21:00 Prime Time'] },
      { day: 'Thursday', slots: ['06:00-10:00 Elite Morning', '12:00-14:00 Express Lunch', '17:00-21:00 Prime Time'] },
      { day: 'Friday', slots: ['06:00-10:00 Elite Morning', '12:00-14:00 Express Lunch', '17:00-21:00 Prime Time'] },
      { day: 'Saturday', slots: ['08:00-12:00 Weekend Warrior'] },
      { day: 'Sunday', slots: ['Recovery Zone Only'] }
    ];

    const handleSubmit = async (e) => {
      e.preventDefault();
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSubmitted(true);
    };

    const handleChange = (e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">Schedule & Booking</h1>
            <p className="text-xl text-gray-400 text-center">
              Reserve your training session or book your free evaluation
            </p>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Weekly Schedule</h2>
            <div className="max-w-4xl mx-auto bg-[var(--bg-dark)] rounded-lg overflow-hidden border border-gray-800">
              {schedule.map((item, index) => (
                <div key={index} className={`p-4 ${index !== schedule.length - 1 ? 'border-b border-gray-800' : ''}`}>
                  <div className="flex flex-col md:flex-row md:items-center">
                    <div className="md:w-1/4 font-bold text-[var(--primary-color)] mb-2 md:mb-0">{item.day}</div>
                    <div className="md:w-3/4">
                      {item.slots.map((slot, idx) => (
                        <div key={idx} className="text-gray-400 mb-1">{slot}</div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Book Your Session</h2>
            <div className="max-w-2xl mx-auto">
              {submitted ? (
                <div className="bg-[var(--secondary-color)] p-8 rounded-lg border border-[var(--primary-color)] text-center">
                  <div className="w-16 h-16 bg-[var(--primary-color)] bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="icon-check text-3xl text-[var(--primary-color)]"></div>
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Booking Received!</h3>
                  <p className="text-gray-400">We'll contact you shortly to confirm your session.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="bg-[var(--secondary-color)] p-8 rounded-lg border border-gray-800">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <input
                      type="text"
                      name="name"
                      placeholder="Full Name"
                      value={formData.name}
                      onChange={handleChange}
                      className="px-4 py-3 bg-[var(--bg-dark)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                      required
                    />
                    <input
                      type="email"
                      name="email"
                      placeholder="Email"
                      value={formData.email}
                      onChange={handleChange}
                      className="px-4 py-3 bg-[var(--bg-dark)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                      required
                    />
                  </div>
                  <div className="mb-6">
                    <input
                      type="tel"
                      name="phone"
                      placeholder="Phone Number"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[var(--bg-dark)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                      required
                    />
                  </div>
                  <div className="mb-6">
                    <select
                      name="program"
                      value={formData.program}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[var(--bg-dark)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                      required
                    >
                      <option value="">Select Program</option>
                      <option value="individual">Individual Coaching</option>
                      <option value="group">Small-Group Training</option>
                      <option value="recovery">Recovery Add-on</option>
                      <option value="evaluation">Free Evaluation</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <input
                      type="date"
                      name="date"
                      value={formData.date}
                      onChange={handleChange}
                      className="px-4 py-3 bg-[var(--bg-dark)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                      required
                    />
                    <input
                      type="time"
                      name="time"
                      value={formData.time}
                      onChange={handleChange}
                      className="px-4 py-3 bg-[var(--bg-dark)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                      required
                    />
                  </div>
                  <button type="submit" className="btn-primary w-full">Book Now</button>
                </form>
              )}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('ScheduleApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ScheduleApp />);