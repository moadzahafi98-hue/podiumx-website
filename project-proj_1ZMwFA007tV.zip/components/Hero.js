function Hero() {
  try {
    return (
      <section className="relative h-screen flex items-center justify-center bg-cover bg-center" style={{backgroundImage: 'url(https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1920&q=80)'}} data-name="hero" data-file="components/Hero.js">
        <div className="absolute inset-0 bg-black bg-opacity-70"></div>
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 text-white">
            Elevate Your Performance
          </h1>
          <p className="text-2xl md:text-3xl mb-8 text-[var(--primary-color)] font-semibold">
            Every Level, Every Session
          </p>
          <p className="text-xl mb-8 text-gray-300 max-w-2xl mx-auto">
            Elite coaching, proven results, and community-driven training in Casablanca's premier performance center
          </p>
          <a href="schedule.html" className="btn-primary text-lg inline-block">
            Book Your Free Evaluation
          </a>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}