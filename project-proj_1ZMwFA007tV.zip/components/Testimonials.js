function Testimonials() {
  try {
    const [currentIndex, setCurrentIndex] = React.useState(0);
    
    const testimonials = [
      { name: 'Sarah M.', text: 'PodiumX transformed my fitness journey. The coaches are exceptional and the facility is world-class.', rating: 5 },
      { name: 'Ahmed K.', text: 'Best gym in Casablanca! The recovery zone with ice baths is a game-changer for my training.', rating: 5 },
      { name: 'Lisa R.', text: 'Amazing community and results-driven programs. I achieved my goals faster than I imagined.', rating: 5 },
      { name: 'Omar B.', text: 'The coaching expertise and personalized attention make all the difference. Highly recommend!', rating: 5 },
      { name: 'Emma T.', text: 'From beginner to athlete - PodiumX guided me every step. The small group sessions are perfect.', rating: 5 }
    ];

    const nextTestimonial = () => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    };

    const prevTestimonial = () => {
      setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    };

    return (
      <section className="py-20 bg-[var(--bg-dark)]" data-name="testimonials" data-file="components/Testimonials.js">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">What Our Athletes Say</h2>
          <div className="max-w-3xl mx-auto mt-12 relative">
            <div className="bg-[var(--secondary-color)] p-8 rounded-lg border border-gray-800">
              <div className="flex mb-4">
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                  <div key={i} className="icon-star text-xl text-[var(--primary-color)]"></div>
                ))}
              </div>
              <p className="text-xl text-gray-300 mb-6 italic">"{testimonials[currentIndex].text}"</p>
              <p className="text-[var(--primary-color)] font-bold">— {testimonials[currentIndex].name}</p>
            </div>
            <div className="flex justify-center mt-6 space-x-4">
              <button onClick={prevTestimonial} className="w-10 h-10 bg-[var(--primary-color)] bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all">
                <div className="icon-chevron-left text-xl text-white"></div>
              </button>
              <button onClick={nextTestimonial} className="w-10 h-10 bg-[var(--primary-color)] bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all">
                <div className="icon-chevron-right text-xl text-white"></div>
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Testimonials component error:', error);
    return null;
  }
}