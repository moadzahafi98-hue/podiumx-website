function AboutApp() {
  try {
    const coaches = [
      { name: 'Coach Karim', role: 'Lead Coach & Founder', bio: '15+ years in strength & conditioning, former national athlete', image: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400&q=80' },
      { name: 'Coach Amira', role: 'Strength Coach', bio: 'Certified CrossFit L2, specializes in Olympic lifting', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80' },
      { name: 'Coach Hassan', role: 'Recovery Specialist', bio: 'Sports therapy certification, recovery & mobility expert', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80' }
    ];

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">About PodiumX</h1>
            <div className="max-w-3xl mx-auto text-center">
              <p className="text-xl text-gray-300 mb-6">
                Founded by experienced coaches with decades of conditioning expertise, PodiumX Performance Center was born from a simple mission: to bring elite-level training to athletes of all levels.
              </p>
              <p className="text-lg text-gray-400">
                We believe that everyone deserves access to world-class coaching, cutting-edge facilities, and a supportive community. Whether you're a beginner taking your first steps or an elite athlete pushing your limits, PodiumX is your partner in performance.
              </p>
            </div>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold mb-12 text-center">Meet Our Coaches</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {coaches.map((coach, index) => (
                <div key={index} className="bg-[var(--bg-dark)] rounded-lg overflow-hidden border border-gray-800 hover:border-[var(--primary-color)] transition-all">
                  <img src={coach.image} alt={coach.name} className="w-full h-64 object-cover" />
                  <div className="p-6">
                    <h3 className="text-2xl font-bold mb-2">{coach.name}</h3>
                    <p className="text-[var(--primary-color)] mb-3">{coach.role}</p>
                    <p className="text-gray-400">{coach.bio}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold mb-12 text-center">Why Choose PodiumX</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="flex items-start">
                <div className="w-12 h-12 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <div className="icon-check text-2xl text-[var(--primary-color)]"></div>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Expert Guidance</h3>
                  <p className="text-gray-400">Our certified coaches bring years of experience and proven methodologies</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-12 h-12 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <div className="icon-check text-2xl text-[var(--primary-color)]"></div>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Modern Facility</h3>
                  <p className="text-gray-400">245 m² of purpose-built training and recovery spaces</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-12 h-12 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <div className="icon-check text-2xl text-[var(--primary-color)]"></div>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Personalized Approach</h3>
                  <p className="text-gray-400">Every member gets an initial assessment and tailored programming</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-12 h-12 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <div className="icon-check text-2xl text-[var(--primary-color)]"></div>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Recovery Focus</h3>
                  <p className="text-gray-400">Dedicated 30 m² recovery area with ice baths and sauna</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('AboutApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AboutApp />);
