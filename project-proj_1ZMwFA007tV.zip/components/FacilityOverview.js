function FacilityOverview() {
  try {
    const zones = [
      { name: 'Training Zone', size: '100 m²', description: 'Functional rig, barbells, kettlebells, turf sled lane', icon: 'activity' },
      { name: 'Cardio & Reception', size: '100 m²', description: 'Treadmills, assault bikes, rowing machines, lounge', icon: 'heart-pulse' },
      { name: 'Recovery Area', size: '30 m²', description: '2 ice baths, glass sauna, relaxation bench', icon: 'flower-2' },
      { name: 'Locker Rooms', size: '15 m²', description: 'Secure lockers, showers, mirrors', icon: 'key' }
    ];

    return (
      <section className="py-20 bg-[var(--secondary-color)]" data-name="facility-overview" data-file="components/FacilityOverview.js">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">Our Facility</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            {zones.map((zone, index) => (
              <div key={index} className="bg-[var(--bg-dark)] p-6 rounded-lg border border-gray-800 hover:border-[var(--primary-color)] transition-all">
                <div className="flex items-start mb-4">
                  <div className="w-12 h-12 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mr-4">
                    <div className={`icon-${zone.icon} text-2xl text-[var(--primary-color)]`}></div>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-1">{zone.name}</h3>
                    <p className="text-[var(--primary-color)] font-semibold">{zone.size}</p>
                  </div>
                </div>
                <p className="text-gray-400">{zone.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('FacilityOverview component error:', error);
    return null;
  }
}