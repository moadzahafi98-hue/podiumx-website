function ContactApp() {
  try {
    const [formData, setFormData] = React.useState({
      name: '',
      email: '',
      phone: '',
      program: '',
      message: ''
    });
    const [submitted, setSubmitted] = React.useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setFormData({ name: '', email: '', phone: '', program: '', message: '' });
      }, 3000);
    };

    const handleChange = (e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">Contact Us</h1>
            <p className="text-xl text-gray-400 text-center">
              Get in touch with our team
            </p>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
              <div>
                <h2 className="text-3xl font-bold mb-8">Send Us a Message</h2>
                {submitted ? (
                  <div className="bg-[var(--bg-dark)] p-8 rounded-lg border border-[var(--primary-color)] text-center">
                    <div className="w-16 h-16 bg-[var(--primary-color)] bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <div className="icon-check text-3xl text-[var(--primary-color)]"></div>
                    </div>
                    <h3 className="text-2xl font-bold mb-2">Message Sent!</h3>
                    <p className="text-gray-400">We'll get back to you within 24 hours.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="bg-[var(--bg-dark)] p-8 rounded-lg border border-gray-800">
                    <div className="mb-6">
                      <input
                        type="text"
                        name="name"
                        placeholder="Full Name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={formData.email}
                        onChange={handleChange}
                        className="px-4 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                        required
                      />
                      <input
                        type="tel"
                        name="phone"
                        placeholder="Phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="px-4 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                      />
                    </div>
                    <div className="mb-6">
                      <select
                        name="program"
                        value={formData.program}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                        required
                      >
                        <option value="">Program Interest</option>
                        <option value="individual">Individual Coaching</option>
                        <option value="group">Small-Group Training</option>
                        <option value="recovery">Recovery Package</option>
                        <option value="corporate">Corporate/Team</option>
                      </select>
                    </div>
                    <div className="mb-6">
                      <textarea
                        name="message"
                        placeholder="Your Message"
                        value={formData.message}
                        onChange={handleChange}
                        rows="4"
                        className="w-full px-4 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                        required
                      ></textarea>
                    </div>
                    <button type="submit" className="btn-primary w-full">Send Message</button>
                  </form>
                )}
              </div>

              <div>
                <h2 className="text-3xl font-bold mb-8">Visit Us</h2>
                <div className="bg-[var(--bg-dark)] p-8 rounded-lg border border-gray-800 mb-6">
                  <div className="flex items-start mb-6">
                    <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                      <div className="icon-map-pin text-2xl text-black"></div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">Location</h3>
                      <p className="text-gray-400">Centre Casablanca-Settat</p>
                      <p className="text-gray-400">Casablanca, Morocco</p>
                    </div>
                  </div>
                  <div className="flex items-start mb-6">
                    <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                      <div className="icon-phone text-2xl text-black"></div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">Phone</h3>
                      <p className="text-gray-400">+212 (0) XX XXX XXXX</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                      <div className="icon-mail text-2xl text-black"></div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">Email</h3>
                      <p className="text-gray-400">info@podiumx.ma</p>
                    </div>
                  </div>
                </div>

                <div className="bg-[var(--bg-dark)] p-8 rounded-lg border border-gray-800">
                  <h3 className="text-xl font-bold mb-4">Opening Hours</h3>
                  <div className="space-y-3 text-gray-400">
                    <div className="flex justify-between">
                      <span>Monday - Friday</span>
                      <span className="text-[var(--primary-color)]">06:00 - 21:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Saturday</span>
                      <span className="text-[var(--primary-color)]">08:00 - 12:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sunday</span>
                      <span className="text-gray-500">Recovery Zone Only</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('ContactApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ContactApp />);