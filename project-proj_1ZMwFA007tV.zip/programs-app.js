function ProgramsApp() {
  try {
    const programs = [
      {
        name: 'Individual Coaching',
        subtitle: 'One-to-One',
        icon: 'user',
        prices: [
          { sessions: '2 sessions/week', price: '799 MAD/month' },
          { sessions: '4 sessions/week', price: '1199 MAD/month' }
        ],
        includes: [
          'Personalized program design',
          'Initial assessment form',
          'Monthly progress review',
          'Access to all facility zones',
          'Flexible scheduling'
        ]
      },
      {
        name: 'Small-Group Training',
        subtitle: 'Maximum 10 athletes',
        icon: 'users',
        prices: [
          { sessions: '3 sessions/week', price: '549 MAD/month' }
        ],
        includes: [
          'Community-driven training',
          'Structured WOD programs',
          'Strength & conditioning focus',
          'Motivational group environment',
          'Access to training & cardio zones'
        ]
      },
      {
        name: 'Recovery & Regeneration',
        subtitle: 'Add-on Package',
        icon: 'flower-2',
        prices: [
          { sessions: 'Unlimited access', price: '249 MAD/month' }
        ],
        includes: [
          '2 ice baths available',
          'Glass sauna access',
          'Relaxation bench area',
          'Self-guided recovery sessions',
          'Perfect post-workout routine'
        ]
      }
    ];

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">Our Programs</h1>
            <p className="text-xl text-gray-400 text-center max-w-3xl mx-auto">
              All programs include a free initial assessment, welcome kit (shirt + towel), and monthly performance reviews
            </p>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {programs.map((program, index) => (
                <div key={index} className="bg-[var(--bg-dark)] rounded-lg p-8 border border-gray-800 hover:border-[var(--primary-color)] transition-all">
                  <div className="w-16 h-16 bg-[var(--primary-color)] bg-opacity-20 rounded-lg flex items-center justify-center mb-6">
                    <div className={`icon-${program.icon} text-3xl text-[var(--primary-color)]`}></div>
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{program.name}</h3>
                  <p className="text-gray-400 mb-6">{program.subtitle}</p>
                  {program.prices.map((price, idx) => (
                    <div key={idx} className="mb-6">
                      <p className="text-sm text-gray-500">{price.sessions}</p>
                      <p className="text-3xl font-bold text-[var(--primary-color)]">{price.price}</p>
                    </div>
                  ))}
                  <ul className="space-y-3 mb-8">
                    {program.includes.map((item, idx) => (
                      <li key={idx} className="flex items-start">
                        <div className="icon-check text-lg text-[var(--primary-color)] mr-2 mt-1"></div>
                        <span className="text-gray-400">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <a href="schedule.html" className="btn-primary w-full text-center block">Book Now</a>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('ProgramsApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ProgramsApp />);