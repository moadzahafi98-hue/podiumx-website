function LoginApp() {
  try {
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [error, setError] = React.useState('');

    const handleSubmit = async (e) => {
      e.preventDefault();
      setError('');
      
      if (!email || !password) {
        setError('Please enter both email and password');
        return;
      }
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      setError('Demo: Login functionality would be implemented here');
    };

    return (
      <div className="min-h-screen bg-[var(--secondary-color)] flex items-center justify-center px-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-2">PodiumX</h1>
            <p className="text-gray-400">Client Portal Login</p>
          </div>
          
          <div className="bg-[var(--bg-dark)] p-8 rounded-lg border border-gray-800">
            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <label className="block text-sm font-semibold mb-2">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full px-4 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                  required
                />
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-semibold mb-2">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-[var(--secondary-color)] border border-gray-700 rounded text-white focus:outline-none focus:border-[var(--primary-color)]"
                  required
                />
              </div>
              
              {error && (
                <div className="mb-6 p-3 bg-red-900 bg-opacity-20 border border-red-700 rounded text-red-400 text-sm">
                  {error}
                </div>
              )}
              
              <button type="submit" className="btn-primary w-full mb-4">
                Sign In
              </button>
              
              <div className="text-center text-sm text-gray-400">
                <a href="#" className="hover:text-[var(--primary-color)]">Forgot password?</a>
              </div>
            </form>
          </div>
          
          <div className="text-center mt-6">
            <a href="index.html" className="text-gray-400 hover:text-[var(--primary-color)] text-sm">
              ← Back to Home
            </a>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LoginApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<LoginApp />);