function FacilityApp() {
  try {
    const [activeZone, setActiveZone] = React.useState(0);

    const zones = [
      {
        name: 'Training Zone',
        size: '100 m²',
        description: 'Our main training area features a fully equipped functional rig, Olympic barbells, kettlebells, dumbbells, and a premium turf sled lane. Perfect for strength training, functional fitness, and high-intensity workouts.',
        equipment: ['Functional Rig', 'Olympic Barbells', 'Kettlebells', 'Dumbbells', 'Turf Sled Lane', 'Weight Plates'],
        image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80'
      },
      {
        name: 'Cardio & Reception',
        size: '100 m²',
        description: 'State-of-the-art cardio equipment including treadmills, assault bikes, and rowing machines. Our welcoming reception area features a comfortable lounge for pre and post-workout relaxation.',
        equipment: ['Treadmills', 'Assault Bikes', 'Rowing Machines', 'Reception Desk', 'Lounge Area', 'Water Station'],
        image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=800&q=80'
      },
      {
        name: 'Recovery Area',
        size: '30 m²',
        description: 'Dedicated recovery space with 2 professional ice baths and a glass sauna. Complete your training with proper recovery protocols to maximize performance and reduce soreness.',
        equipment: ['2 Ice Baths', 'Glass Sauna', 'Relaxation Bench', 'Recovery Tools', 'Massage Area'],
        image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=80'
      },
      {
        name: 'Locker Rooms',
        size: '15 m²',
        description: 'Clean, secure locker facilities with modern showers, changing areas, and full-length mirrors. Store your belongings safely during your workout.',
        equipment: ['Secure Lockers', 'Modern Showers', 'Changing Benches', 'Full Mirrors', 'Amenities'],
        image: 'https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?w=800&q=80'
      }
    ];

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">Our Facility</h1>
            <p className="text-xl text-gray-400 text-center max-w-3xl mx-auto">
              245 m² of purpose-built training and recovery spaces designed for optimal performance
            </p>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {zones.map((zone, index) => (
                <button
                  key={index}
                  onClick={() => setActiveZone(index)}
                  className={`px-6 py-3 rounded font-bold transition-all ${
                    activeZone === index
                      ? 'bg-[var(--primary-color)] text-black'
                      : 'bg-[var(--bg-dark)] text-white hover:bg-gray-800'
                  }`}
                >
                  {zone.name}
                </button>
              ))}
            </div>

            <div className="max-w-5xl mx-auto">
              <div className="bg-[var(--bg-dark)] rounded-lg overflow-hidden border border-gray-800">
                <img src={zones[activeZone].image} alt={zones[activeZone].name} className="w-full h-96 object-cover" />
                <div className="p-8">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-3xl font-bold">{zones[activeZone].name}</h2>
                    <span className="text-2xl text-[var(--primary-color)] font-bold">{zones[activeZone].size}</span>
                  </div>
                  <p className="text-gray-400 mb-6">{zones[activeZone].description}</p>
                  <h3 className="text-xl font-bold mb-3">Equipment & Features:</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {zones[activeZone].equipment.map((item, idx) => (
                      <div key={idx} className="flex items-center">
                        <div className="icon-check text-base text-[var(--primary-color)] mr-2"></div>
                        <span className="text-gray-400">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('FacilityApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<FacilityApp />);