function Footer() {
  try {
    return (
      <footer className="bg-[var(--secondary-color)] border-t border-gray-800 py-12" data-name="footer" data-file="components/Footer.js">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-bold text-[var(--primary-color)] mb-4">PodiumX</h3>
              <p className="text-gray-400">Elevate Your Performance</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="about.html" className="hover:text-[var(--primary-color)]">About Us</a></li>
                <li><a href="programs.html" className="hover:text-[var(--primary-color)]">Programs</a></li>
                <li><a href="facility.html" className="hover:text-[var(--primary-color)]">Facility</a></li>
                <li><a href="pricing.html" className="hover:text-[var(--primary-color)]">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="faq.html" className="hover:text-[var(--primary-color)]">FAQ</a></li>
                <li><a href="blog.html" className="hover:text-[var(--primary-color)]">Blog</a></li>
                <li><a href="contact.html" className="hover:text-[var(--primary-color)]">Contact</a></li>
                <li><a href="login.html" className="hover:text-[var(--primary-color)]">Client Portal</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Connect</h4>
              <div className="flex space-x-4 mb-4">
                <a href="#" className="w-10 h-10 bg-[var(--primary-color)] bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30">
                  <div className="icon-instagram text-xl text-white"></div>
                </a>
                <a href="#" className="w-10 h-10 bg-[var(--primary-color)] bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30">
                  <div className="icon-facebook text-xl text-white"></div>
                </a>
                <a href="#" className="w-10 h-10 bg-[var(--primary-color)] bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30">
                  <div className="icon-linkedin text-xl text-white"></div>
                </a>
              </div>
              <p className="text-gray-400 text-sm">info@podiumx.ma</p>
              <p className="text-gray-400 text-sm">+212 (0) XX XXX XXXX</p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2025 PodiumX Performance Center. All rights reserved.</p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}