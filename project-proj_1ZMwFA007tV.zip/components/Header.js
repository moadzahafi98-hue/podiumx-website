function Header() {
  try {
    const [isScrolled, setIsScrolled] = React.useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

    React.useEffect(() => {
      const handleScroll = () => {
        setIsScrolled(window.scrollY > 50);
      };
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navItems = [
      { label: 'Home', href: 'index.html' },
      { label: 'About', href: 'about.html' },
      { label: 'Programs', href: 'programs.html' },
      { label: 'Schedule', href: 'schedule.html' },
      { label: 'Facility', href: 'facility.html' },
      { label: 'Pricing', href: 'pricing.html' },
      { label: 'Blog', href: 'blog.html' },
      { label: 'Contact', href: 'contact.html' }
    ];

    return (
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-[var(--secondary-color)] shadow-lg' : 'bg-transparent'}`} data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold text-[var(--primary-color)]">PodiumX</div>
          
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item, index) => (
              <a key={index} href={item.href} className="text-white hover:text-[var(--primary-color)] transition-colors">
                {item.label}
              </a>
            ))}
            <a href="schedule.html" className="btn-primary">Book Now</a>
          </nav>

          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="md:hidden text-white">
            <div className="icon-menu text-2xl"></div>
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden bg-[var(--bg-dark)] border-t border-gray-800">
            <nav className="container mx-auto px-4 py-4 flex flex-col space-y-4">
              {navItems.map((item, index) => (
                <a key={index} href={item.href} className="text-white hover:text-[var(--primary-color)] transition-colors">
                  {item.label}
                </a>
              ))}
              <a href="schedule.html" className="btn-primary text-center">Book Now</a>
            </nav>
          </div>
        )}
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}