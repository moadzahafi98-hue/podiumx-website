function PricingTeaser() {
  try {
    return (
      <section className="py-20 bg-[var(--secondary-color)]" data-name="pricing-teaser" data-file="components/PricingTeaser.js">
        <div className="container mx-auto px-4 text-center">
          <h2 className="section-title">Flexible Membership Options</h2>
          <p className="text-3xl text-[var(--primary-color)] font-bold mb-8">From 499 MAD/month</p>
          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Choose from individual coaching, small-group training, or recovery add-ons. All programs include a free initial assessment.
          </p>
          <a href="pricing.html" className="btn-primary text-lg">
            View All Plans
          </a>
        </div>
      </section>
    );
  } catch (error) {
    console.error('PricingTeaser component error:', error);
    return null;
  }
}