# PodiumX Performance Center Website

## Overview
Complete website for PodiumX Performance Center - an elite fitness and performance training facility in Casablanca, Morocco.

## Brand Identity
- **Name**: PodiumX Performance Center
- **Tagline**: "Elevate Your Performance • Every Level, Every Session"
- **Colors**: Matte black (#000000), Electric green (#00FF5E), White (#FFFFFF)
- **Style**: Minimalist, bold, athlete-focused aesthetic

## Website Structure

### Pages
1. **Home (index.html)** - Hero, benefits, facility overview, testimonials, pricing teaser
2. **About (about.html)** - Story, coaches, why choose PodiumX
3. **Programs (programs.html)** - Individual coaching, group training, recovery packages
4. **Schedule (schedule.html)** - Weekly timetable and booking form
5. **Facility (facility.html)** - Detailed zones with images
6. **Pricing (pricing.html)** - Complete pricing table with offers
7. **Blog (blog.html)** - Articles and insights
8. **Contact (contact.html)** - Contact form and location info
9. **FAQ (faq.html)** - Common questions
10. **Login (login.html)** - Client portal access

### Facility Zones
- **Training Zone** (100 m²) - Functional rig, barbells, kettlebells, turf sled lane
- **Cardio & Reception** (100 m²) - Treadmills, assault bikes, rowing machines
- **Recovery Area** (30 m²) - 2 ice baths, glass sauna
- **Locker Rooms** (15 m²) - Secure lockers, showers, mirrors

### Programs & Pricing
- **Small-Group Training**: 549 MAD/month (3 sessions/week)
- **Individual Coaching 2x/week**: 799 MAD/month
- **Individual Coaching 4x/week**: 1199 MAD/month
- **Recovery Add-on**: 249 MAD/month (unlimited)
- **Special Offers**: 10% off 12-month contract, referral bonus

### Schedule
- **Monday-Friday**: 06:00-10:00 (Elite Morning), 12:00-14:00 (Express Lunch), 17:00-21:00 (Prime Time)
- **Saturday**: 08:00-12:00 (Weekend Warrior)
- **Sunday**: Recovery Zone Only

## Technical Stack
- React 18
- TailwindCSS
- Lucide Icons
- Multi-page architecture (MPA)

## Features
- Responsive design
- Mobile-friendly navigation
- Booking forms
- Newsletter signup
- Contact forms
- SEO optimized
- Accessibility compliant

## Contact Information
- **Location**: Centre Casablanca-Settat, Casablanca, Morocco
- **Email**: info@podiumx.ma
- **Phone**: +212 (0) XX XXX XXXX

## Last Updated
2025-11-02