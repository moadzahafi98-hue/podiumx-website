function FAQApp() {
  try {
    const [openIndex, setOpenIndex] = React.useState(null);

    const faqs = [
      {
        question: 'Do I need prior experience?',
        answer: 'No, all levels are welcome at PodiumX. Our coaches specialize in working with beginners through advanced athletes. We start with a free initial assessment to understand your current fitness level and goals.'
      },
      {
        question: 'What equipment do you use?',
        answer: 'We use minimal but powerful equipment including functional rigs, Olympic barbells, kettlebells, dumbbells, turf sled lanes, assault bikes, treadmills, rowing machines, ice baths, and a glass sauna.'
      },
      {
        question: 'Can I freeze or cancel my membership?',
        answer: 'Yes, you can freeze your membership for up to 2 months per year. Cancellation requires 30 days written notice. Please contact us for specific terms and conditions.'
      },
      {
        question: 'Are lockers included?',
        answer: 'Yes, secure lockers are included for all members during their training sessions. We provide modern shower facilities and full amenities in our locker rooms.'
      },
      {
        question: 'What safety measures are in place?',
        answer: 'All coaches are certified professionals, equipment is maintained daily, and we follow strict hygiene protocols. First aid kits are available, and coaches are trained in emergency procedures.'
      },
      {
        question: 'What should I bring to my first session?',
        answer: 'Bring comfortable workout clothes, athletic shoes, a water bottle, and a towel. We provide all training equipment. Locker facilities are available for storing your belongings.'
      },
      {
        question: 'Do you offer corporate packages?',
        answer: 'Yes, we offer custom corporate and team packages. Contact us directly to discuss your organization\'s needs and get a tailored quote.'
      },
      {
        question: 'How do I access the recovery zone?',
        answer: 'Recovery zone access is included with all individual coaching memberships or available as a standalone add-on for 249 MAD/month. Ice baths and sauna are self-guided during facility hours.'
      }
    ];

    const toggleFAQ = (index) => {
      setOpenIndex(openIndex === index ? null : index);
    };

    return (
      <div className="min-h-screen bg-[var(--secondary-color)]">
        <Header />
        
        <section className="pt-32 pb-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 text-center">Frequently Asked Questions</h1>
            <p className="text-xl text-gray-400 text-center">
              Find answers to common questions about PodiumX
            </p>
          </div>
        </section>

        <section className="py-20 bg-[var(--secondary-color)]">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto space-y-4">
              {faqs.map((faq, index) => (
                <div key={index} className="bg-[var(--bg-dark)] rounded-lg border border-gray-800 overflow-hidden">
                  <button
                    onClick={() => toggleFAQ(index)}
                    className="w-full p-6 text-left flex items-center justify-between hover:bg-gray-900 transition-colors"
                  >
                    <span className="text-lg font-bold pr-4">{faq.question}</span>
                    <div className={`icon-${openIndex === index ? 'chevron-up' : 'chevron-down'} text-xl text-[var(--primary-color)] flex-shrink-0`}></div>
                  </button>
                  {openIndex === index && (
                    <div className="px-6 pb-6">
                      <p className="text-gray-400">{faq.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-[var(--bg-dark)]">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">Still Have Questions?</h2>
            <p className="text-gray-400 mb-8">
              Contact our team and we'll be happy to help
            </p>
            <a href="contact.html" className="btn-primary">Contact Us</a>
          </div>
        </section>

        <Footer />
      </div>
    );
  } catch (error) {
    console.error('FAQApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<FAQApp />);
