function Benefits() {
  try {
    const benefits = [
      { icon: 'trophy', title: 'Elite Coaching', description: 'Certified coaches with years of experience' },
      { icon: 'target', title: 'Proven Results', description: 'Track progress with monthly reviews' },
      { icon: 'dumbbell', title: 'Minimal Equipment', description: 'Powerful, focused training tools' },
      { icon: 'users', title: 'Community Driven', description: 'Train with motivated athletes' }
    ];

    return (
      <section className="py-20 bg-[var(--bg-dark)]" data-name="benefits" data-file="components/Benefits.js">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-[var(--primary-color)] bg-opacity-20 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <div className={`icon-${benefit.icon} text-3xl text-[var(--primary-color)]`}></div>
                </div>
                <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                <p className="text-gray-400">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Benefits component error:', error);
    return null;
  }
}